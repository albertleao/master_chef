#
# Cookbook Name:: homesync-php-app
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
